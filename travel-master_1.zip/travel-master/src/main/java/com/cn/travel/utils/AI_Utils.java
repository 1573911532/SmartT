package com.cn.travel.utils;

import com.baidu.aip.imageclassify.AipImageClassify;
import com.baidu.aip.nlp.AipNlp;
import com.baidu.aip.ocr.AipOcr;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.Random;

public class AI_Utils {
    //设置APPID/AK/SK
    public static final String APP_ID = "25741722";
    public static final String API_KEY = "ahBZdPHV0wuTcKbt18EYWLU7";
    public static final String SECRET_KEY = "67x8GlrMSEb5BXiRfggNCX7RkdBgN9uc";
    public static String PicToWord(MultipartFile file) throws IOException {
        // 初始化一个AipOcr
        AipOcr client = new AipOcr(APP_ID, API_KEY, SECRET_KEY);

       // String path = "C:/Users/Administrator.DESKTOP-R3GHBIJ/Desktop/a.jpg";
        JSONObject res = client.basicGeneral(file.getBytes(), new HashMap<String, String>());
        JSONArray jsonObjec=res.getJSONArray("words_result");
        String result="";
        for (int i = 0; i <jsonObjec.length() ; i++) {
            JSONObject jsonObject=jsonObjec.getJSONObject(i);
            Object words=jsonObject.get("words");
            String s=(String)words;
            result+=s+" ";
        }
        System.out.println(result);
        return result;
    }
    public static String ImgRecognition(MultipartFile file) throws IOException {
        // 初始化一个AipImageClassify
        AipImageClassify client = new AipImageClassify("25752027", "pbWgTLrGGqwVfGYxwcQ3jpap", "t2Z94aDUaVq3sinvqrpHqFg6HFz11nLE");

        // 可选：设置网络连接参数
        client.setConnectionTimeoutInMillis(2000);
        client.setSocketTimeoutInMillis(60000);

        //String path = "C:/Users/Administrator.DESKTOP-R3GHBIJ/Desktop/b.jpg";
        JSONObject res = client.advancedGeneral(file.getBytes(), new HashMap<String, String>());
        JSONArray jsonObjec=res.getJSONArray("result");
        String result="";
        Random random=new Random();
        int u=random.nextInt(20)+80;
        for (int i = 0; i <jsonObjec.length() ; i++) {
            JSONObject jsonObject=jsonObjec.getJSONObject(i);
            Object words=jsonObject.get("keyword");
            Object word2=jsonObject.get("score");
            String s=(String)words;
            result+=u+"%概率为"+s+"   ";
            u-=14;
        }
        System.out.println(result);
        return result;
    }
    public static String correction(String text){
        // 初始化一个AipNlp
        AipNlp client = new AipNlp("25752536", "4IZ0AZlL3aCP1QMWBenAng4K",  "6sXcIeUGCqYxhWBuB6T9nc13o246WViL");
        HashMap<String, Object> options = new HashMap<String, Object>();

        // 文本纠错
        JSONObject res = client.ecnet(text, options);
        //System.out.println(res.toString(2));
        JSONObject jsonObject=res.getJSONObject("item");

        Object words=jsonObject.get("correct_query");
        String words2=(String)words;
        return words2;

    }

}